var Item = require('./model');
exports.index = function(req, res) {
  Item.find(function (err, items) {
    return res.status(200).json(items);
  });
};
