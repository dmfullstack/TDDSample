// create a new app
var express = require('express');
var app = express();
var controller = require('./controller.js');

app.use('/', controller.index);

app.listen(8080);
