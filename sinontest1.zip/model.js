var mongoose = require("mongoose");

var items = mongoose.Schema({
  itemno: String,
  itemname: String,
});

module.exports = mongoose.model("items", items);
